ULTRON AI — phone-first PWA prototype

FILES
- index.html: user interface, voice input, spoken responses, basic commands
- manifest.json: installable PWA metadata
- sw.js: basic offline caching

IMPORTANT LIMITATIONS
- This is a prototype, not a full generative AI assistant.
- Browser speech recognition availability depends on browser/device and may require internet.
- Wake-word listening in the background is not implemented.
- It cannot unlock the phone or bypass Android security.
- It does not have unrestricted access to apps, messages, or files.
- Do not put private API keys into index.html. For a real AI model, use a backend service that protects the key.

TO USE ON YOUR PHONE
1. Upload these three files to a GitHub repository.
2. In the repository, open Settings > Pages.
3. Choose Deploy from a branch, select main and /(root), then Save.
4. Open the published HTTPS site in Chrome on Android.
5. Use Chrome's menu > Add to Home screen / Install app.
6. Allow microphone permission when prompted.

For local testing, speech recognition may not work from a file:// URL; serve it from HTTPS.
